import CarouselSection from "../components/carouselSection";
import ItemSection from "../components/itemSection";
import HeaderContainer from "../containers/headerContainer";
import styled from "styled-components";
import backGroundImg from "./mainHeaderBackground.jpg";
import FooterContainer from "../containers/FooterContainer";
import SearchBar from "../components/searchBar";

const Header = styled.header`
  height: 349px;
  background-image: url(${backGroundImg});
  background-repeat: no-repeat;
  background-size: cover;
  font-weight: bolder;
  color: white;
  padding-top: 150px;
  text-align: center;
  .title{
    font-size: 2.2rem;
    margin: 0;
  }
`;

function MainPage() {
    return (
        <div>
            <HeaderContainer/>
            <Header>
                <p className={"title"}>솔직한 리뷰, 믿을 수 있는 평점!</p>
                <h1 className={"title"}>망고플레이트</h1>
                <SearchBar/>
            </Header>
            <CarouselSection/>
            <ItemSection/>
            <FooterContainer/>
        </div>
    );
}

export default MainPage;