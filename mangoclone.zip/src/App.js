import MainPage from "./Pages/mainPage";


function App() {
  return (
      <div>
          <MainPage/>
      </div>
  );
}

export default App;
