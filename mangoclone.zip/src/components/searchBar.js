import React, {useState} from "react";
import styled from "style-component";


function SearchBar() {
    return (
        <form>
            <input
                type="string"
                placeholder="지역, 식당 또는 음식"
            />
            <button type={"submit"}>검색</button>
        </form>
    );
}

export default SearchBar;